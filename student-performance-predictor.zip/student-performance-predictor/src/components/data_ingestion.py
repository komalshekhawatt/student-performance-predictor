import os
import sys
import pandas as pd
from sklearn.model_selection import train_test_split
from dataclasses import dataclass

from src.exception import CustomException
from src.logger import logging

# 1. Configuration Class: Tells the script exactly where to save the files.
@dataclass
class DataIngestionConfig:
    train_data_path: str = os.path.join('artifacts', "train.csv")
    test_data_path: str = os.path.join('artifacts', "test.csv")
    raw_data_path: str = os.path.join('artifacts', "data.csv")

# 2. The Main Class: Does the heavy lifting
class DataIngestion:
    def __init__(self):
        self.ingestion_config = DataIngestionConfig()

    def initiate_data_ingestion(self):
        logging.info("Entered the data ingestion method or component")
        print(" Starting Data Ingestion Pipeline...")
        try:
            # Step A: Read the raw dataset
            df = pd.read_csv('notebook/data/stud.csv')
            logging.info('Read the dataset as dataframe')
            print(" Read the dataset as a Pandas DataFrame")

            # Clean up the column names just like we did in the notebook
            df.columns = df.columns.str.replace(' ', '_').str.replace('/', '_')

            # Step B: Create the artifacts folder if it doesn't exist
            os.makedirs(os.path.dirname(self.ingestion_config.train_data_path), exist_ok=True)

            # Step C: Save a copy of the raw data into the vault
            df.to_csv(self.ingestion_config.raw_data_path, index=False, header=True)

            # Step D: Split the data into Train and Test sets
            logging.info("Train test split initiated")
            print(" Initiating Train-Test Split...")
            train_set, test_set = train_test_split(df, test_size=0.2, random_state=42)

            # Step E: Save the splits into the vault
            train_set.to_csv(self.ingestion_config.train_data_path, index=False, header=True)
            test_set.to_csv(self.ingestion_config.test_data_path, index=False, header=True)

            logging.info("Ingestion of the data is completed")
            print(" Data Ingestion Completed Successfully!")

            return (
                self.ingestion_config.train_data_path,
                self.ingestion_config.test_data_path
            )
        except Exception as e:
            print(f" Error during Data Ingestion: {e}")
            raise CustomException(e, sys)

# --- Code to test the script ---
if __name__=="__main__":
    obj = DataIngestion()
    train_data, test_data = obj.initiate_data_ingestion()
    print(f"Train data saved at: {train_data}")
    print(f"Test data saved at: {test_data}")
