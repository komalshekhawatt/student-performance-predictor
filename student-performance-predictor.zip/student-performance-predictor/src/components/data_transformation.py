import sys
import os
from dataclasses import dataclass
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from src.exception import CustomException
from src.logger import logging
from src.utils import save_object

# 1. Configuration: Tells the script where to save the preprocessor.pkl file
@dataclass
class DataTransformationConfig:
    preprocessor_obj_file_path: str = os.path.join('artifacts', "preprocessor.pkl")

# 2. The Main Class
class DataTransformation:
    def __init__(self):
        self.data_transformation_config = DataTransformationConfig()

    def get_data_transformer_object(self):
        """
        This function creates and returns the ColumnTransformer object.
        """
        try:
            numerical_columns = ["writing_score", "reading_score"]
            categorical_columns = [
                "gender",
                "race_ethnicity",
                "parental_level_of_education",
                "lunch",
                "test_preparation_course",
            ]

            num_pipeline = Pipeline(
                steps=[
                    ("imputer", SimpleImputer(strategy="median")),
                    ("scaler", StandardScaler())
                ]
            )

            cat_pipeline = Pipeline(
                steps=[
                    ("imputer", SimpleImputer(strategy="most_frequent")),
                    ("one_hot_encoder", OneHotEncoder()),
                ]
            )

            logging.info(f"Categorical columns: {categorical_columns}")
            logging.info(f"Numerical columns: {numerical_columns}")

            preprocessor = ColumnTransformer(
                [
                    ("num_pipeline", num_pipeline, numerical_columns),
                    ("cat_pipeline", cat_pipeline, categorical_columns)
                ]
            )

            return preprocessor
        
        except Exception as e:
            print(f"Error building transformer: {e}")
            raise CustomException(e, sys)
        
    def initiate_data_transformation(self, train_path, test_path):
        try:
            print("Starting Data Transformation...")
            
            # Step A: Read the train and test data from the artifacts vault
            train_df = pd.read_csv(train_path)
            test_df = pd.read_csv(test_path)

            logging.info("Read train and test data completed")
            print("Read train and test data successfully.")

            # Step B: Get the preprocessor object we built above
            logging.info("Obtaining preprocessing object")
            print("Loading the Preprocessor object...")
            preprocessing_obj = self.get_data_transformer_object()

            # Step C: Separate the Target Feature (math_score)
            target_column_name = "math_score"

            input_feature_train_df = train_df.drop(columns=[target_column_name])
            target_feature_train_df = train_df[target_column_name]

            input_feature_test_df = test_df.drop(columns=[target_column_name])
            target_feature_test_df = test_df[target_column_name]

            # Step D: Apply the transformation
            logging.info("Applying preprocessing object on training dataframe and testing dataframe.")
            print("Applying preprocessing object on training and testing datasets...")

            input_feature_train_arr = preprocessing_obj.fit_transform(input_feature_train_df)
            input_feature_test_arr = preprocessing_obj.transform(input_feature_test_df)

            # Step E: Combine the transformed features and the target into arrays
            train_arr = np.c_[
                input_feature_train_arr, np.array(target_feature_train_df)
            ]
            test_arr = np.c_[input_feature_test_arr, np.array(target_feature_test_df)]

            # Step F: Save the preprocessor as a .pkl file in the artifacts folder
            logging.info(f"Saved preprocessing object.")

            save_object(
                file_path=self.data_transformation_config.preprocessor_obj_file_path,
                obj=preprocessing_obj
            )

            print(f"Preprocessor saved at: {self.data_transformation_config.preprocessor_obj_file_path}")
            print(" ✅ Data Transformation Completed Successfully!")

            return (
                train_arr,
                test_arr,
                self.data_transformation_config.preprocessor_obj_file_path,
            )
        except Exception as e:
            print(f"Error during Data Transformation: {e}")
            raise CustomException(e, sys)

# --- Code to test the script ---
if __name__ == "__main__":
    # We simulate receiving these paths from data_ingestion.py
    train_data_path = "artifacts/train.csv"
    test_data_path = "artifacts/test.csv"
    
    obj = DataTransformation()
    train_array, test_array, preprocessor_path = obj.initiate_data_transformation(train_data_path, test_data_path)
    
    print(f"Processed Train Array Shape: {train_array.shape}")
    print(f"Processed Test Array Shape: {test_array.shape}")
